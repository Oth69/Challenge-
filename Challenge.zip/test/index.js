var fs = require('fs');
// Function to calculate the change given based on the denominations available
function calculateChange(changeAmount, denominations) {
    var change = [];
    denominations.sort(function (a, b) { return b - a; }); // Sort denominations in descending order
    for (var _i = 0, denominations_1 = denominations; _i < denominations_1.length; _i++) {
        var denomination = denominations_1[_i];
        while (changeAmount >= denomination) {
            changeAmount -= denomination;
            change.push(denomination);
        }
    }
    return change;
}
// Function to process a single transaction
function processTransaction(till, items, paid) {
    var transactionItems = [];
    var paidAmounts = [];
    for (var i = 0; i < items.length; i++) {
        var lineItems = items[i].split(";");
        for (var j = 0; j < lineItems.length; j++) {
            var variables = lineItems[j].split(",");
            for (var k = 0; k < variables.length; k++) {
                transactionItems.push(variables[k].trim()); // Push each variable separately
            }
        }
    }
    console.log("Transaction Items:", transactionItems);
    for (var i = 0; i < paid.length; i++) {
        var amounts = paid[i].map(function (amounts) {
            var matches = amounts.split('-');
            return matches.reduce(function (acc, match) {
                var value = match.match(/R(\d+)/);
                return acc + (value ? parseInt(value[1]) : 0);
            }, 0);
        });
        paidAmounts.push(amounts);
    }
    console.log("Paid Amounts:", paidAmounts);
    var transactionTotal = transactionItems.reduce(function (acc, item) {
        var _a = item.split(" R"), price = _a[1];
        return acc + parseInt(price);
    }, 0);
    console.log("Transaction Total:", transactionTotal);
    var totalPaid = paidAmounts.flat().reduce(function (acc, amount) { return acc + amount; }, 0);
    console.log("Total Paid:", totalPaid);
    var changeTotal = totalPaid - transactionTotal;
    console.log("Change Total:", changeTotal);
    var changeBreakdown = calculateChange(changeTotal, [200, 100, 50, 20, 10, 5, 2, 1]);
    console.log("Change Breakdown:", changeBreakdown);
    var tillAfterTransaction = till + totalPaid;
    console.log("Till After Transaction:", tillAfterTransaction);
    var output = "".concat(transactionItems.join("; "), "\nPaid Amounts: [").concat(paidAmounts.map(function (arr) { return arr.join(', '); }).join(' - '), "]\nTransaction Total: ").concat(transactionTotal, "\nTotal Paid: ").concat(totalPaid, "\nChange Total: ").concat(changeTotal, "\nChange Breakdown: [").concat(changeBreakdown.join(', '), "]\nTill After Transaction: ").concat(tillAfterTransaction);
    return [tillAfterTransaction, output];
}
// Function to read input file, process transactions and write output file
function processInput(inputFile, outputFile) {
    var inputLines = fs.readFileSync(inputFile, 'utf-8').trim().split('\n');
    var till = 500; // Initial till float
    var outputLines = [];
    for (var _i = 0, inputLines_1 = inputLines; _i < inputLines_1.length; _i++) {
        var line = inputLines_1[_i];
        var segments = line.split(';');
        var transactionItems = [];
        var transactionPaid = [];
        for (var _a = 0, segments_1 = segments; _a < segments_1.length; _a++) {
            var segment = segments_1[_a];
            var _b = segment.split(','), itemsStr = _b[0], paidStr = _b.slice(1);
            var items = itemsStr.split(',');
            var paid = paidStr.map(function (amounts) { return amounts.trim().split(','); });
            transactionItems.push.apply(transactionItems, items);
            transactionPaid.push.apply(transactionPaid, paid);
        }
        var _c = processTransaction(till, transactionItems, transactionPaid), tillAfterTransaction = _c[0], output = _c[1];
        till = tillAfterTransaction;
        outputLines.push(output);
    }
    // Write output to file
    fs.writeFileSync(outputFile, outputLines.join('\n') + "\nTill After All Transactions: ".concat(till));
}
// Main function
function main() {
    var inputFile = 'input.txt';
    var outputFile = 'output.txt';
    processInput(inputFile, outputFile);
}
main();
