const fs = require('fs');

// Function to calculate the change given based on the denominations available
function calculateChange(changeAmount, denominations) {
    const change = [];
    denominations.sort((a, b) => b - a); // Sort denominations in descending order
    for (const denomination of denominations) {
        while (changeAmount >= denomination) {
            changeAmount -= denomination;
            change.push(denomination);
        }
    }
    return change;
}

// Function to process a single transaction
function processTransaction(till, items, paid) {
    let transactionItems = [];
    const paidAmounts = [];

    for (let i = 0; i < items.length; i++) {
        const lineItems = items[i].split(";");

        for (let j = 0; j < lineItems.length; j++) {
            const variables = lineItems[j].split(",");
            for (let k = 0; k < variables.length; k++) {
                transactionItems.push(variables[k].trim()); // Push each variable separately
            }
        }
    }

    console.log("Transaction Items:", transactionItems);

    for (let i = 0; i < paid.length; i++) {
        const amounts = paid[i].map(amounts => {
            const matches = amounts.split('-');
            return matches.reduce((acc, match) => {
                const value = match.match(/R(\d+)/);
                return acc + (value ? parseInt(value[1]) : 0);
            }, 0);
        });
        paidAmounts.push(amounts);
    }

    console.log("Paid Amounts:", paidAmounts);

    const transactionTotal = transactionItems.reduce((acc, item) => {
        const [, price] = item.split(" R");
        return acc + parseInt(price);
    }, 0);

    console.log("Transaction Total:", transactionTotal);

    const totalPaid = paidAmounts.flat().reduce((acc, amount) => acc + amount, 0);
    console.log("Total Paid:", totalPaid);

    const changeTotal = totalPaid - transactionTotal;
    console.log("Change Total:", changeTotal);

    const changeBreakdown = calculateChange(changeTotal, [200, 100, 50, 20, 10, 5, 2, 1]);
    console.log("Change Breakdown:", changeBreakdown);

    const tillAfterTransaction = till + totalPaid;
    console.log("Till After Transaction:", tillAfterTransaction);

    const output = `${transactionItems.join("; ")}\nPaid Amounts: [${paidAmounts.map(arr => arr.join(', ')).join(' - ')}]\nTransaction Total: ${transactionTotal}\nTotal Paid: ${totalPaid}\nChange Total: ${changeTotal}\nChange Breakdown: [${changeBreakdown.join(', ')}]\nTill After Transaction: ${tillAfterTransaction}`;
    return [tillAfterTransaction, output];
}

// Function to read input file, process transactions and write output file
function processInput(inputFile, outputFile) {
    const inputLines = fs.readFileSync(inputFile, 'utf-8').trim().split('\n');
    let till = 500; // Initial till float
    const outputLines = [];

    for (const line of inputLines) {
        const segments = line.split(';');
        const transactionItems = [];
        const transactionPaid = [];
        for (const segment of segments) {
            const [itemsStr, ...paidStr] = segment.split(',');
            const items = itemsStr.split(',');
            const paid = paidStr.map(amounts => amounts.trim().split(','));
            transactionItems.push(...items);
            transactionPaid.push(...paid);
        }
        const [tillAfterTransaction, output] = processTransaction(till, transactionItems, transactionPaid);
        till = tillAfterTransaction;
        outputLines.push(output);
    }

    // Write output to file
    fs.writeFileSync(outputFile, outputLines.join('\n') + `\nTill After All Transactions: ${till}`);
}

// Main function
function main() {
    const inputFile = 'input.txt';
    const outputFile = 'output.txt';
    processInput(inputFile, outputFile);
}

main();
